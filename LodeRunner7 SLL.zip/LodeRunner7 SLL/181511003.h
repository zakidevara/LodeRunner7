#ifndef AGHNIYA003_H
#define AGHNIYA003_H

#include "main.h"
#include "181511057.h"


bool isStanding(signed char arr[BARIS][KOLOM], int baris, int kolom);

bool isClimbing(signed char arr[BARIS][KOLOM], int baris, int kolom);

bool isSliding(signed char arr[BARIS][KOLOM], int baris, int kolom);

bool isFalling(signed char arr[BARIS][KOLOM], int baris, int kolom);

void playerMovement(char *movement, signed char arr[BARIS][KOLOM], int* barisPlayer, int* kolomPlayer, int *X, int* Y, arrayQueue* P, int*urutanBom);
//memindahkan posisi player dalam matriks sesuai movement yang dipilih oleh user
#endif // 181511003_H

