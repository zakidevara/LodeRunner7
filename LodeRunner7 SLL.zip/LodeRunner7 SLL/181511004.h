#ifndef AGUS004_H
#define AGUS004_H

#include "main.h"

bool done(signed char arr[BARIS][KOLOM], int baris, int kolom);
bool adakoin(signed char arr[BARIS][KOLOM]);

#endif // 181511004_H
