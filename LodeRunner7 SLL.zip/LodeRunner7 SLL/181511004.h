#ifndef AGUS004_H
#define AGUS004_H

#include "main.h"

bool done(int8_t arr[BARIS][KOLOM], int baris, int kolom);
bool adakoin(int8_t arr[BARIS][KOLOM]);

#endif // 181511004_H
