#ifndef AGUS004_H
#define AGUS004_H

#include "main.h"

bool done(int arr[BARIS][KOLOM], int baris, int kolom);
bool adakoin(int arr[BARIS][KOLOM]);

#endif // 181511004_H
