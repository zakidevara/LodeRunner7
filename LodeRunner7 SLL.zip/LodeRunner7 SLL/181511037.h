#ifndef ISAL037_H
#define ISAL037_H

#include "main.h"
#include "181511028.h"

void drawDown(int8_t arr[BARIS][KOLOM], int kolom, int baris, int n);

void drawUp(int8_t arr[BARIS][KOLOM], int kolom, int baris, int n);

void drawRight(int8_t arr[BARIS][KOLOM], int kolom, int baris, int n);

void drawLeft(int8_t arr[BARIS][KOLOM], int kolom, int baris, int n);

void menutama();


#endif
