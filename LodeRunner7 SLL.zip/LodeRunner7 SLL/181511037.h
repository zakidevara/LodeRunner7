#ifndef ISAL037_H
#define ISAL037_H

#include "main.h"
#include "181511028.h"

void drawDown(int arr[BARIS][KOLOM], int kolom, int baris, int n);

void drawUp(int arr[BARIS][KOLOM], int kolom, int baris, int n);

void drawRight(int arr[BARIS][KOLOM], int kolom, int baris, int n);

void drawLeft(int arr[BARIS][KOLOM], int kolom, int baris, int n);

void menutama();


#endif
