#ifndef ISAL037_H
#define ISAL037_H

#include "main.h"
#include "181511028.h"

void drawDown(signed char arr[BARIS][KOLOM], int kolom, int baris, int n);

void drawUp(signed char arr[BARIS][KOLOM], int kolom, int baris, int n);

void drawRight(signed char arr[BARIS][KOLOM], int kolom, int baris, int n);

void drawLeft(signed char arr[BARIS][KOLOM], int kolom, int baris, int n);

void menutama();


#endif
