#include "181511004.h"

// DEKLARASI MODUL
bool done(int8_t arr[BARIS][KOLOM], int baris, int kolom)
{
	if (arr[baris][kolom] == 5)
	{
		return true;
	}else{
		return false;
	}
}

bool adakoin(int8_t arr[BARIS][KOLOM])
{
	for(int i=0; i<BARIS; i++)
	{
		for(int j=0; j<KOLOM; j++)
		{
			if(arr[i][j] == 4){
				return true;
			}
		}
	}
	return false;
}
