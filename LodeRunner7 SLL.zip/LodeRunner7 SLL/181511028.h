#ifndef RENOL028_H
#define RENOL028_H

#include "main.h"

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define BARIS 16
#define KOLOM 28
#define MTX_SIZE (BARIS * KOLOM)

/* Struktur data.  */
 
typedef struct node
{
  signed char arr[BARIS][KOLOM];
  struct node *link;
} *pnode_t;

/* Metode.  */

pnode_t pnode (void);  /* Alokasi memori node.  */
void add_head (pnode_t *phead);  /* Menambahkan kepala.  */
void add_tail (pnode_t *phead);  /* Menambahkan ekor.  */
void add_node (pnode_t *phead, size_t index);  /* Menambahkan node.  */
pnode_t plist (size_t sum);  /* Alokasi memori sebuah daftar.  */
void sub_head (pnode_t *phead);  /* Menghapus kepala.  */
void sub_tail (pnode_t *phead);  /* Menghapus ekor.  */
void sub_node (pnode_t *phead, size_t index);  /* Menghapus node.  */
void sub_list (pnode_t *phead);  /* Menghapus daftar.  */
void rev_list (pnode_t *phead);  /* Membalik daftar.  */
size_t sum_node (pnode_t phead);  /* Mencari jumlah node dari daftar.  */
void print_arr (pnode_t phead);  /* Menampilkan array.  */
long file_size (const char *fname);  /* Mencari ukuran berkas.  */
void save_level (pnode_t phead, const char *fname);  /* Menyimpan data dari RAM ke Memori sekunder.  */
void load_level (pnode_t *phead, const char *fname);  /* Memuat isi file ke dalam RAM.  */
pnode_t node (pnode_t phead, int level);  /* Mencari node berdasarkan indeks.  */

/////////////////////////////////////////////////////////////////////////////////

void drawRope(int x1,int y1,int x2, int y2);
void drawCoin(int x1,int y1,int x2, int y2);
void drawExit(int x1,int y1,int x2, int y2);
void drawLadder(int x1,int y1,int x2, int y2);
void drawBlock(int x1,int y1,int x2, int y2);
void drawBedRock(int x1,int y1,int x2, int y2);

///////////////////////////////////////////////////////////////////////////////////

bool isinbrick(signed char arr[BARIS][KOLOM], int barisPlayer, int kolomPlayer, int *Nyawa);
bool ismeetbot(signed char arr[BARIS][KOLOM], int barisPlayer, int kolomPlayer, int *Nyawa);

#ifdef __cplusplus
}
#endif

#endif
