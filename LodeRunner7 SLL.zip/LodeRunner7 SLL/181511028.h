#ifndef RENOL028_H
#define RENOL028_H

#include "main.h"

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>

#define END_LOOP ((size_t) 0)
#define LEAP_LOOP ((size_t) 1)
#define SZ (size_t)

#define BARIS 16
#define KOLOM 28
#define MTX_SIZE (BARIS * KOLOM)

/**
 * Data Structure
 */
 
typedef struct node
{
  int8_t arr[BARIS][KOLOM];
  struct node *next;
} *pnode_t;

/**
 * Method
 */

volatile bool null (void *p); // check pointer \* Bisa digunakan untuk semua jenis pointer
pnode_t pnode (void); // membuat node
static void __plist_loop (pnode_t *lp, size_t sum_node);
pnode_t plist (size_t sum_node); // membuat list sebanyak sum node
void add_tail (pnode_t *lp); // tambahkan node di depan list
void sub_head (pnode_t *lp); // hapus node di depan list
void sub_list (pnode_t *lp); // hapus list
pnode_t level (pnode_t lp, size_t index); // akses node berdasarkan indeks mulai dari 0
void print_arr (pnode_t lp); // menampilkan matriks didalam node
long file_size (FILE *fp_read); // mencari ukuran file \* pointer file perlu realokasi
void save_level (pnode_t lp, FILE *fp_write); // menyimpan node kedalam file
void load_level (pnode_t *lp, FILE *fp_read, long file_size); // me-load data file kedalam list

/////////////////////////////////////////////////////////////////////////////////

void drawRope(int x1,int y1,int x2, int y2);
void drawCoin(int x1,int y1,int x2, int y2);
void drawExit(int x1,int y1,int x2, int y2);
void drawLadder(int x1,int y1,int x2, int y2);
void drawBlock(int x1,int y1,int x2, int y2);
void drawBedRock(int x1,int y1,int x2, int y2);

///////////////////////////////////////////////////////////////////////////////////

bool isinbrick(int8_t arr[BARIS][KOLOM], int barisPlayer, int kolomPlayer, int *Nyawa);
bool ismeetbot(int8_t arr[BARIS][KOLOM], int barisPlayer, int kolomPlayer, int *Nyawa);

#ifdef __cplusplus
}
#endif

#endif
