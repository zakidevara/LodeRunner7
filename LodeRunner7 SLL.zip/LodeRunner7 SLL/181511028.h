#ifndef RENOL028_H
#define RENOL028_H

#include "main.h"
#include <stdio.h>
#include <stdlib.h>

/* Struktur Data.  */

#define BARIS 16
#define KOLOM 28

typedef struct
  {
    int lv;
    int arr[BARIS][KOLOM];
    posisiMatriks exitPos;
    posisiMatriks playerPos;
    posisiMatriks botPos[5];
    int jmlBot;
  } infoLevel;

typedef struct node
  {
    infoLevel info;
    struct node *next;
  } *pnode_t;

/* Metode.  */

volatile bool null (void *__ptr);  /* Periksa pointer.  */
pnode_t pnode (void);  /* Alokasi memori untuk node.  */
void add_head (pnode_t *phead);  /* Menambahkan kepala.  */
void add_tail (pnode_t *phead);  /* Menambahkan ekor.  */
void add_node (pnode_t *phead, size_t index);  /* Menambahkan node.  */
pnode_t plist (size_t sum);  /* Alokasi memori sebuah daftar.  */
void sub_head (pnode_t *phead);  /* Menghapus kepala.  */
void sub_tail (pnode_t *phead);  /* Menghapus ekor.  */
void sub_node (pnode_t *phead, size_t index);  /* Menghapus node.  */
void sub_list (pnode_t *phead);  /* Menghapus daftar.  */
void rev_list (pnode_t *phead);  /* Membalik daftar.  */
size_t sum_node (pnode_t phead);  /* Mencari jumlah node dari daftar.  */
void print_node (pnode_t phead);  /* Menampilkan konten node.  */

long file_size (const char *fname);  /* Mencari ukuran berkas.  */
void load_level (pnode_t *phead, const char *fname);  /* Memuat berkas ke dalam daftar yang dibuat otomatis.  */
void load_info (pnode_t pnode, const char *fname);  /* Memuat berkas ke dalam node.  */

pnode_t access_node (pnode_t phead, size_t index);  /* Mencari node berdasarkan indeks.  */
pnode_t node (pnode_t phead, int level);  /* Mencari node berdasarkan level.  */

/////////////////////////////////////////////////////////////////////////////////

void drawRope(int x1,int y1,int x2, int y2);
void drawCoin(int x1,int y1,int x2, int y2);
void drawExit(int x1,int y1,int x2, int y2);
void drawLadder(int x1,int y1,int x2, int y2);
void drawBlock(int x1,int y1,int x2, int y2);
void drawBedRock(int x1,int y1,int x2, int y2);

///////////////////////////////////////////////////////////////////////////////////

bool isinbrick(int arr[BARIS][KOLOM], int barisPlayer, int kolomPlayer, int *Nyawa);
bool ismeetbot(int arr[BARIS][KOLOM], int barisPlayer, int kolomPlayer, int *Nyawa);

#endif  /* RENOL028_H */
