#include <stdio.h>
#include <graphics.h>
#include <conio.h>

void drawDown(addrs_t *arr, int kolom, int baris, int n) {
    for (int i = 0; i < n; i ++) {
        if (access(arr, baris + i, kolom)->stage == 1)
            drawBlock(MATRIX_ELEMENT_SIZE * kolom, MATRIX_ELEMENT_SIZE * (baris + i), MATRIX_ELEMENT_SIZE * (kolom + 1), MATRIX_ELEMENT_SIZE * (baris + 1 + i));
        if (access(arr, baris + i, kolom)->stage == 2)
            drawLadder(MATRIX_ELEMENT_SIZE * kolom, MATRIX_ELEMENT_SIZE * (baris + i), MATRIX_ELEMENT_SIZE * (kolom + 1), MATRIX_ELEMENT_SIZE * (baris + 1 + i));
        if (access(arr, baris + i, kolom)->stage == 3)
            drawRope(MATRIX_ELEMENT_SIZE * kolom, MATRIX_ELEMENT_SIZE * (baris + i), MATRIX_ELEMENT_SIZE * (kolom + 1), MATRIX_ELEMENT_SIZE * (baris + 1 + i));
        if (access(arr, baris + i, kolom)->stage == 4)
            drawCoin(MATRIX_ELEMENT_SIZE * kolom, MATRIX_ELEMENT_SIZE * (baris + i), MATRIX_ELEMENT_SIZE * (kolom + 1), MATRIX_ELEMENT_SIZE * (baris + 1 + i));
        if (access(arr, baris + i, kolom)->stage == 5)
            drawExit(MATRIX_ELEMENT_SIZE * kolom, MATRIX_ELEMENT_SIZE * (baris + i), MATRIX_ELEMENT_SIZE * (kolom + 1), MATRIX_ELEMENT_SIZE * (baris + 1 + i));
        if (access(arr, baris + i, kolom)->bot == 1)
            drawBot(MATRIX_ELEMENT_SIZE * kolom, MATRIX_ELEMENT_SIZE * (baris + i), MATRIX_ELEMENT_SIZE * (kolom + 1), MATRIX_ELEMENT_SIZE * (baris + 1 + i));
    }
}

void drawUp(addrs_t *arr, int kolom, int baris, int n) {
    for (int i = 0; i < n; i ++) {
        if (access(arr, baris - i, kolom)->stage == 1)
            drawBlock(MATRIX_ELEMENT_SIZE * kolom, MATRIX_ELEMENT_SIZE * (baris - i), MATRIX_ELEMENT_SIZE * (kolom + 1), MATRIX_ELEMENT_SIZE * (baris + 1 - i));
        if (access(arr, baris - i, kolom)->stage == 2)
            drawLadder(MATRIX_ELEMENT_SIZE * kolom, MATRIX_ELEMENT_SIZE * (baris - i), MATRIX_ELEMENT_SIZE * (kolom + 1), MATRIX_ELEMENT_SIZE * (baris + 1 - i));
        if (access(arr, baris - i, kolom)->stage == 3)
            drawRope(MATRIX_ELEMENT_SIZE * kolom, MATRIX_ELEMENT_SIZE * (baris - i), MATRIX_ELEMENT_SIZE * (kolom + 1), MATRIX_ELEMENT_SIZE * (baris + 1 - i));
        if (access(arr, baris - i, kolom)->stage == 4)
            drawCoin(MATRIX_ELEMENT_SIZE * kolom, MATRIX_ELEMENT_SIZE * (baris - i), MATRIX_ELEMENT_SIZE * (kolom + 1), MATRIX_ELEMENT_SIZE * (baris + 1 - i));
        if (access(arr, baris - i, kolom)->stage == 5)
            drawExit(MATRIX_ELEMENT_SIZE * kolom, MATRIX_ELEMENT_SIZE * (baris - i), MATRIX_ELEMENT_SIZE * (kolom + 1), MATRIX_ELEMENT_SIZE * (baris + 1 - i));
        if (access(arr, baris - i, kolom)->bot == 1)
            drawBot(MATRIX_ELEMENT_SIZE * kolom, MATRIX_ELEMENT_SIZE * (baris - i), MATRIX_ELEMENT_SIZE * (kolom + 1), MATRIX_ELEMENT_SIZE * (baris + 1 - i));
    }
}

void drawRight(addrs_t *arr, int kolom, int baris, int n) {
    for(int i = 0; i < n; i ++) {
        if (access(arr, baris, kolom + i)->stage == 1)
            drawBlock(MATRIX_ELEMENT_SIZE * (kolom + i), MATRIX_ELEMENT_SIZE * (baris), MATRIX_ELEMENT_SIZE * (kolom + i + 1), MATRIX_ELEMENT_SIZE * (baris + 1));
        if (access(arr, baris, kolom + i)->stage == 2)
            drawLadder(MATRIX_ELEMENT_SIZE * (kolom + i), MATRIX_ELEMENT_SIZE * (baris), MATRIX_ELEMENT_SIZE * (kolom + i + 1), MATRIX_ELEMENT_SIZE * (baris + 1));
        if (access(arr, baris, kolom + i)->stage == 3)
            drawRope(MATRIX_ELEMENT_SIZE * (kolom + i), MATRIX_ELEMENT_SIZE * (baris), MATRIX_ELEMENT_SIZE * (kolom + i + 1), MATRIX_ELEMENT_SIZE * (baris + 1));
        if (access(arr, baris, kolom + i)->stage == 4)
            drawCoin(MATRIX_ELEMENT_SIZE * (kolom + i), MATRIX_ELEMENT_SIZE * (baris), MATRIX_ELEMENT_SIZE * (kolom + i + 1), MATRIX_ELEMENT_SIZE * (baris + 1));
        if (access(arr, baris, kolom + i)->stage == 5)
            drawExit(MATRIX_ELEMENT_SIZE * (kolom + i), MATRIX_ELEMENT_SIZE * (baris), MATRIX_ELEMENT_SIZE * (kolom + i + 1), MATRIX_ELEMENT_SIZE * (baris + 1));
        if (access(arr, baris, kolom + i)->bot == 1)
            drawBot(MATRIX_ELEMENT_SIZE * (kolom + i), MATRIX_ELEMENT_SIZE * (baris), MATRIX_ELEMENT_SIZE * (kolom + i + 1), MATRIX_ELEMENT_SIZE * (baris + 1));
    }
}

void drawLeft(addrs_t *arr, int kolom, int baris, int n) {
    for (int i = 0; i < n; i ++) {
        if (access(arr, baris, kolom - i)->stage == 1)
            drawBlock(MATRIX_ELEMENT_SIZE * (kolom - i), MATRIX_ELEMENT_SIZE * (baris), MATRIX_ELEMENT_SIZE * (kolom - i + 1), MATRIX_ELEMENT_SIZE * (baris + 1));
        if (access(arr, baris, kolom - i)->stage == 2)
            drawLadder(MATRIX_ELEMENT_SIZE * (kolom - i), MATRIX_ELEMENT_SIZE * (baris), MATRIX_ELEMENT_SIZE * (kolom - i + 1), MATRIX_ELEMENT_SIZE * (baris + 1));
        if (access(arr, baris, kolom - i)->stage == 3)
            drawRope(MATRIX_ELEMENT_SIZE * (kolom - i), MATRIX_ELEMENT_SIZE * (baris), MATRIX_ELEMENT_SIZE * (kolom - i + 1), MATRIX_ELEMENT_SIZE * (baris + 1));
        if (access(arr, baris, kolom - i)->stage == 4)
            drawCoin(MATRIX_ELEMENT_SIZE * (kolom - i), MATRIX_ELEMENT_SIZE * (baris), MATRIX_ELEMENT_SIZE * (kolom - i + 1), MATRIX_ELEMENT_SIZE * (baris + 1));
        if (access(arr, baris, kolom - i)->stage == 5)
            drawExit(MATRIX_ELEMENT_SIZE * (kolom - i), MATRIX_ELEMENT_SIZE * (baris), MATRIX_ELEMENT_SIZE * (kolom - i + 1), MATRIX_ELEMENT_SIZE * (baris + 1));
        if (access(arr, baris, kolom - i)->bot == 1)
            drawBot(MATRIX_ELEMENT_SIZE * (kolom - i), MATRIX_ELEMENT_SIZE * (baris), MATRIX_ELEMENT_SIZE * (kolom - i + 1), MATRIX_ELEMENT_SIZE * (baris + 1));
    }
}
