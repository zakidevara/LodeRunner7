#include <stdio.h>
#include <graphics.h>
#include <conio.h>

bool done(addrs_t *arr, int baris, int kolom) {
	if (access(arr, baris, kolom)->stage == 5)
		return true;
	else
		return false;
}
