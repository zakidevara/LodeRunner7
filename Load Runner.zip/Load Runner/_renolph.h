#include <stdio.h>
#include <graphics.h>
#include <conio.h>

void drawRope(int x1, int y1, int x2, int y2) {   //menggambar tali
    readimagefile("images/slide.gif", x1, y1, x2 - 1, y2 - 1);
}

void drawCoin(int x1, int y1, int x2, int y2) {   //menggambar koin
    readimagefile("images/goal.gif", x1, y1, x2 - 1, y2 - 1);
}

void drawExit(int x1, int y1, int x2, int y2) {   //menggambar pintu
    readimagefile("images/exit.gif", x1, y1, x2 - 1, y2 - 1);
}

void drawLadder(int x1, int y1, int x2, int y2) { //menggambar tangga
    readimagefile("images/ladder.gif", x1 , y1, x2 - 1, y2 - 1);
}

void drawBlock(int x1, int y1, int x2, int y2) {    //menggambar block
    readimagefile("images/wall.gif", x1, y1, x2 - 1, y2 - 1);
}
