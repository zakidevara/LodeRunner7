#include <stdio.h>
#include <graphics.h>
#include <conio.h>
#include "matriks.h"

#define WINDOWS_HEIGHT 600
#define WINDOWS_WIDTH 800

#define MATRIX_ELEMENT_SIZE 25
#define BARIS 600/MATRIX_ELEMENT_SIZE
#define KOLOM 800/MATRIX_ELEMENT_SIZE

void hitung_skor(int* skor);

void tampil_skor(int skor);

void drawRope(int x1,int y1,int x2, int y2);

void drawCoin(int x1,int y1,int x2, int y2);

void drawExit(int x1,int y1,int x2, int y2);

void drawLadder(int x1,int y1,int x2, int y2);

void drawPlayerRight(int x1,int y1,int x2, int y2);

void drawPlayerLeft(int x1,int y1,int x2, int y2);

void drawBot(int x1,int y1,int x2, int y2);

void drawBlock(int x1,int y1,int x2, int y2);

void insertBot(addrs_t *arr,int baris, int kolom);

void insertPlayer(addrs_t *arr,int baris, int kolom);

void deleteBot(addrs_t *arr, int baris, int kolom);

void deletePlayer(addrs_t *arr,int baris, int kolom);

void level1(addrs_t *arr,int* barisPlayer, int* kolomPlayer);

void generateStage(addrs_t *arr, int level, int* barisPlayer, int* kolomPlayer);

void drawStage(addrs_t *arr);

void drawStageNoPlayer(addrs_t *arr);

void drawStageBaris(addrs_t *arr, int baris);

void drawStageKolom(addrs_t *arr, int kolom);

void drawDown(addrs_t *arr, int kolom, int baris, int n);

void drawUp(addrs_t *arr, int kolom, int baris, int n);

void drawRight(addrs_t *arr, int kolom, int baris, int n);

void drawLeft(addrs_t *arr, int kolom, int baris, int n);

bool isStanding(addrs_t *arr, int baris, int kolom);

bool isClimbing(addrs_t *arr, int baris, int kolom);

bool isSliding(addrs_t *arr, int baris, int kolom);

bool isFalling(addrs_t *arr, int baris, int kolom);

bool isNabrak(addrs_t *arr, int baris, int kolom, int arah);

bool done(addrs_t *arr, int baris, int kolom);

void playerMovement(char movement, addrs_t *arr, int* barisPlayer, int* kolomPlayer);

bool lagiNgambilKoin(addrs_t *arr, int baris, int kolom );

void drawPlayerMovement(char movement, addrs_t *arr, int barisPlayer, int kolomPlayer);

bool isGerak(addrs_t *arr, int baris, int kolom, int barisBef, int kolomBef);

void loading();

void prosesInput(char *movement);
