// Struktur data baru

#ifndef matriksh
#define matriksh

#include <stdio.h>
#include <stdlib.h>

// struktur data untuk elemen matriks dalam single linked list
// digunakan struktur ini karena jika dalam double linked list terdapat pointer yang tidak terpakai saat akses elemen
// pointer yang tidak terpakai menyebabkan kompleksitas ruang yang tidak efisien
// ini mereduksi kira-kira 2/5 ruang memori saat matriks dibangun, jika menggunakan double linked list

typedef struct _snode *elmt_t;
typedef struct _snode {
	int stage;
	int player;
	int bot;
	elmt_t next;
} snode_t;

// struktur data untuk indeks baris matriks dalam double link
// digunakan struktur ini karena untuk akses elemen hanya memerlukan satu jalan atau efektifitas penggunaan pointer
// struktur ini memiliki kompleksitas waktu yang sama dengan matriks yang menggunakan double linked list
// yaitu kira-kira baris + kolom instruksi (operasi) untuk mengakses elemen

typedef struct _index *arr_t;
typedef struct _index {
	arr_t back;
	elmt_t front;
} index_t;

void __crtsnode(elmt_t *ptr);
void __crtindex(arr_t *ptr);
void __crtslist(elmt_t *ptr, int sum_snode);

void crtarr(arr_t *ptr, int lenrow, int lencol);
elmt_t acselmt(arr_t *identifier, int row, int coloum);

void __crtsnode(elmt_t *ptr) {
	*ptr = (elmt_t) malloc(sizeof (snode_t));
	
	if (*ptr != 0LL) {
		(*ptr)->stage = 0;
		(*ptr)->player = 0;
		(*ptr)->bot = 0;
		(*ptr)->next = 0LL;
	}
	
	return;
}

void __crtindex(arr_t *ptr) {
	*ptr = (arr_t) malloc(sizeof (index_t));
	
	if (*ptr != 0LL) {
		(*ptr)->back = 0LL;
		(*ptr)->front = 0LL;
	}
	
	return;
}

void __crtslist(elmt_t *ptr, int sum_snode) {
	__crtsnode(ptr);
	
	if (*ptr != 0LL)
		if (sum_snode != 1)
			return __crtslist(&(*ptr)->next, sum_snode - 1);
			
	return;
}

void crtarr(arr_t *ptr, int lenrow, int lencol) {
	*ptr = 0LL;
	__crtindex(ptr);
	
	if (*ptr != 0LL) {
		__crtslist(&(*ptr)->front, lencol);
		
		if (lenrow != 1)
			return crtarr(&(*ptr)->back, lenrow - 1, lencol);
	}
	
	return;
}

elmt_t acselmt(arr_t *identifier, int row, int coloum) {
	if (*identifier != 0LL) {
		arr_t index_postn = *identifier;
		
		elmt_t elmt_postn = 0LL;
		int trc_loop = 0;
	
		for (trc_loop = 0; trc_loop < row; trc_loop ++)
			index_postn = index_postn->back;
		elmt_postn = index_postn->front;
		
		for (trc_loop = 0; trc_loop < coloum; trc_loop ++)
			elmt_postn = elmt_postn->next;
		return (elmt_postn);
	}
	
	else
		return 0LL;
}

#endif
