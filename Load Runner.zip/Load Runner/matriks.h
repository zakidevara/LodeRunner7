// Creator : Renol P. H.
// Struktur data lama

#ifndef matriks
#define matriks

typedef struct _node *addrs_t;
typedef struct _node {
	int stage;
	int player;
	int bot;
	addrs_t next;
} node_t;

void __create_node(addrs_t *pointer);
void __create_list(addrs_t *pointer, unsigned sum_node);

void create_matrix(addrs_t *identifier, unsigned short length_row, unsigned short length_coloum);
addrs_t access(addrs_t *identifier, unsigned row, unsigned coloum);

void __create_node(addrs_t *pointer) {
	*pointer = (addrs_t) malloc(sizeof (node_t));
	
	(*pointer)->stage = 0;
	(*pointer)->player = 0;
	
	(*pointer)->bot = 0;
	(*pointer)->next = 0LL;
}

void __create_list(addrs_t *pointer, unsigned sum_node) {
	__create_node(pointer);
	addrs_t trc_node = *pointer;
	
	if (sum_node == 1)
		return;
	else
		return __create_list(&trc_node->next, sum_node - 1);
}

void create_matrix(addrs_t *identifier, unsigned short length_row, unsigned short length_coloum) {
	unsigned sum_node = length_row * length_coloum;
	
	__create_list(identifier, sum_node);
	addrs_t trc_node = *identifier;
	
	while (trc_node->next != 0LL)
		trc_node = trc_node->next;
	
	__create_node(&trc_node->next);
	trc_node->next->stage = length_row;
	
	__create_node(&trc_node->next->next);
	trc_node->next->next->stage = length_coloum;
}

addrs_t access(addrs_t *identifier, unsigned row, unsigned coloum) {
	addrs_t node_coloum = *identifier;
	addrs_t elmt_postn = *identifier;
	
	while (node_coloum->next != 0LL)
		node_coloum = node_coloum->next;
	
	const unsigned short const_coloum = node_coloum->stage;
	unsigned trc, leap = (row * const_coloum) + coloum;
	
	for (trc = 1; trc <= leap; trc ++)
		elmt_postn = elmt_postn->next;
	
	return (elmt_postn);
}

#endif
